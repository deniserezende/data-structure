//
//  commandline.h -> interprets the commandline set for the second project of Data Structure
//  
//
//  Created by Denise F. de Rezende on 04/06/21.
// 

#ifndef commandline_h
#define commandline_h

void commandline(int argc, char *argv[], char **input_path, char **geo_filename, char **qry_filename, char **output_path);

#endif /* commandline_h */
