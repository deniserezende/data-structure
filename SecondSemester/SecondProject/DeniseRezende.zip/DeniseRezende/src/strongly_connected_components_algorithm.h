#ifndef strongly_connected_components_algorithm_h
#define strongly_connected_components_algorithm_h

#include "graph.h"

void strongly_connected_components_algorithm(type_graph graph, int solution_vector[]);

#endif